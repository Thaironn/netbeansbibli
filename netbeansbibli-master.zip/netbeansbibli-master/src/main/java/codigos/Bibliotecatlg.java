/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package codigos;

import java.awt.List;
import java.util.ArrayList;

/**
 *
 * @author aluno tds
 */
public class Bibliotecatlg {
    
    private List<Livro> livro = new ArrayList<Livro>();
    private List<Emprestimos> Emprestimos = new ArrayList<Emprestimos>();
    private int ContagemEmprestimos = 0;
    private int ContagemLivro = 0;
    
    
}
